export interface IProduct {
    name: string;
    description: string;
    price: number;
    category: number;
    image: string;
    active: boolean;
    id: string;
}
