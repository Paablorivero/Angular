
import { Component, inject } from '@angular/core';
import { IProduct } from '../../Interfaces/iproduct';
import { ProductService } from '../../Services/product-service';
import { ProductCard } from "../../Components/product-card/product-card";
import { RouterLink } from "@angular/router";

@Component({
  selector: 'app-products',
  imports: [ProductCard, RouterLink],
  templateUrl: './products.html',
  styleUrl: './products.css',
})
export class Products {
  arrayProducts: IProduct[];
  serviceProducts = inject(ProductService)

  constructor(){
    this.arrayProducts = this.serviceProducts.getAll();
  }

  ngOnInit(): void{
    this.arrayProducts = this.serviceProducts.getAll();
  }
}
